import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Clientes.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb9b7777";
import { api } from "/src/api.js";
var _jsxFileName = "C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Clientes.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb9b7777";
var _s = $RefreshSig$();
export default function Clientes() {
	_s();
	const [clientes, setClientes] = useState([]);
	const [nome, setNome] = useState("");
	const [email, setEmail] = useState("");
	const [editandoId, setEditandoId] = useState(null);
	const [erro, setErro] = useState("");
	const carregar = () => api("/clientes").then(setClientes);
	useEffect(() => {
		carregar();
	}, []);
	function limpar() {
		setNome("");
		setEmail("");
		setEditandoId(null);
		setErro("");
	}
	async function salvar(e) {
		e.preventDefault();
		try {
			if (editandoId) {
				await api(`/clientes/${editandoId}`, "PUT", {
					nome,
					email
				});
			} else {
				await api("/clientes", "POST", {
					nome,
					email
				});
			}
			limpar();
			carregar();
		} catch (err) {
			setErro(err.message);
		}
	}
	function editar(cliente) {
		setNome(cliente.nome);
		setEmail(cliente.email);
		setEditandoId(cliente.id);
	}
	async function remover(id) {
		await api(`/clientes/${id}`, "DELETE");
		carregar();
	}
	return /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "Clientes" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: salvar,
			children: [
				/* @__PURE__ */ _jsxDEV("input", {
					"aria-label": "Nome",
					placeholder: "Nome",
					value: nome,
					onChange: (e) => setNome(e.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					"aria-label": "Email",
					placeholder: "Email",
					value: email,
					onChange: (e) => setEmail(e.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					children: editandoId ? "Salvar" : "Cadastrar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				editandoId && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: limpar,
					children: "Cancelar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 24
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 7
		}, this),
		erro && /* @__PURE__ */ _jsxDEV("p", {
			className: "erro",
			children: erro
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 16
		}, this),
		/* @__PURE__ */ _jsxDEV("table", { children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("th", { children: "Nome" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Email" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 28
			}, this),
			/* @__PURE__ */ _jsxDEV("th", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 42
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: clientes.map((c) => /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("td", { children: c.nome }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: c.email }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => editar(c),
					children: "Editar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 17
				}, this),
				" ",
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => remover(c.id),
					children: "Remover"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 17
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 15
			}, this)
		] }, c.id, true, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
}
_s(Clientes, "wQGGRgFnDbIXb3nfkOZlYiy3Gac=");
_c = Clientes;
var _c;
$RefreshReg$(_c, "Clientes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Clientes.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Clientes.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Clientes.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Clientes.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLFdBQVc7Ozs7QUFFcEIsZUFBZSxTQUFTLFdBQVc7O0NBQ2pDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FDM0MsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsSUFBSTtDQUNqRCxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUVuQyxNQUFNLGlCQUFpQixJQUFJLFdBQVcsQ0FBQyxDQUFDLEtBQUssV0FBVztDQUV4RCxnQkFBZ0I7RUFDZCxTQUFTO0NBQ1gsR0FBRyxDQUFDLENBQUM7Q0FFTCxTQUFTLFNBQVM7RUFDaEIsUUFBUSxFQUFFO0VBQ1YsU0FBUyxFQUFFO0VBQ1gsY0FBYyxJQUFJO0VBQ2xCLFFBQVEsRUFBRTtDQUNaO0NBRUEsZUFBZSxPQUFPLEdBQUc7RUFDdkIsRUFBRSxlQUFlO0VBQ2pCLElBQUk7R0FDRixJQUFJLFlBQVk7SUFDZCxNQUFNLElBQUksYUFBYSxjQUFjLE9BQU87S0FBRTtLQUFNO0lBQU0sQ0FBQztHQUM3RCxPQUFPO0lBQ0wsTUFBTSxJQUFJLGFBQWEsUUFBUTtLQUFFO0tBQU07SUFBTSxDQUFDO0dBQ2hEO0dBQ0EsT0FBTztHQUNQLFNBQVM7RUFDWCxTQUFTLEtBQUs7R0FDWixRQUFRLElBQUksT0FBTztFQUNyQjtDQUNGO0NBRUEsU0FBUyxPQUFPLFNBQVM7RUFDdkIsUUFBUSxRQUFRLElBQUk7RUFDcEIsU0FBUyxRQUFRLEtBQUs7RUFDdEIsY0FBYyxRQUFRLEVBQUU7Q0FDMUI7Q0FFQSxlQUFlLFFBQVEsSUFBSTtFQUN6QixNQUFNLElBQUksYUFBYSxNQUFNLFFBQVE7RUFDckMsU0FBUztDQUNYO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7O0VBQ2hCLHdCQUFDLFFBQUQ7R0FBTSxVQUFVO2FBQWhCO0lBQ0Usd0JBQUMsU0FBRDtLQUFPLGNBQVc7S0FBTyxhQUFZO0tBQU8sT0FBTztLQUFNLFdBQVcsTUFBTSxRQUFRLEVBQUUsT0FBTyxLQUFLO0lBQUk7Ozs7O0lBQ3BHLHdCQUFDLFNBQUQ7S0FBTyxjQUFXO0tBQVEsYUFBWTtLQUFRLE9BQU87S0FBTyxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztJQUFJOzs7OztJQUN4Ryx3QkFBQyxVQUFEO0tBQVEsTUFBSztlQUFVLGFBQWEsV0FBVztJQUFvQjs7Ozs7SUFDbEUsY0FBYyx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFNBQVM7ZUFBUTtJQUFnQjs7Ozs7R0FDbEU7Ozs7OztFQUNMLFFBQVEsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBUTtFQUFROzs7OztFQUV0Qyx3QkFBQyxTQUFELGFBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7R0FBSSx3QkFBQyxNQUFELFlBQUksT0FBUTs7Ozs7R0FBQyx3QkFBQyxNQUFELFlBQUksUUFBUzs7Ozs7R0FBQyx3QkFBQyxNQUFELENBQVE7Ozs7O0VBQUs7Ozs7V0FDdkM7Ozs7WUFDUCx3QkFBQyxTQUFELFlBQ0csU0FBUyxLQUFLLE1BQ2Isd0JBQUMsTUFBRDtHQUNFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLEtBQVM7Ozs7O0dBQ2hCLHdCQUFDLE1BQUQsWUFBSyxFQUFFLE1BQVU7Ozs7O0dBQ2pCLHdCQUFDLE1BQUQ7SUFDRSx3QkFBQyxVQUFEO0tBQVEsZUFBZSxPQUFPLENBQUM7ZUFBRztJQUFjOzs7OztJQUFFO0lBQ2xELHdCQUFDLFVBQUQ7S0FBUSxlQUFlLFFBQVEsRUFBRSxFQUFFO2VBQUc7SUFBZTs7Ozs7R0FDbkQ7Ozs7O0VBQ0YsS0FQSyxFQUFFOzs7O1NBT1AsQ0FDTCxFQUNJOzs7O1VBQ0Y7Ozs7O0NBQ0E7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2xpZW50ZXMuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IGFwaSB9IGZyb20gJy4uL2FwaS5qcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDbGllbnRlcygpIHtcclxuICBjb25zdCBbY2xpZW50ZXMsIHNldENsaWVudGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbm9tZSwgc2V0Tm9tZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2VkaXRhbmRvSWQsIHNldEVkaXRhbmRvSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Vycm8sIHNldEVycm9dID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBjYXJyZWdhciA9ICgpID0+IGFwaSgnL2NsaWVudGVzJykudGhlbihzZXRDbGllbnRlcyk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjYXJyZWdhcigpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgZnVuY3Rpb24gbGltcGFyKCkge1xyXG4gICAgc2V0Tm9tZSgnJyk7XHJcbiAgICBzZXRFbWFpbCgnJyk7XHJcbiAgICBzZXRFZGl0YW5kb0lkKG51bGwpO1xyXG4gICAgc2V0RXJybygnJyk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBzYWx2YXIoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGVkaXRhbmRvSWQpIHtcclxuICAgICAgICBhd2FpdCBhcGkoYC9jbGllbnRlcy8ke2VkaXRhbmRvSWR9YCwgJ1BVVCcsIHsgbm9tZSwgZW1haWwgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgYXBpKCcvY2xpZW50ZXMnLCAnUE9TVCcsIHsgbm9tZSwgZW1haWwgfSk7XHJcbiAgICAgIH1cclxuICAgICAgbGltcGFyKCk7XHJcbiAgICAgIGNhcnJlZ2FyKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJybyhlcnIubWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBlZGl0YXIoY2xpZW50ZSkge1xyXG4gICAgc2V0Tm9tZShjbGllbnRlLm5vbWUpO1xyXG4gICAgc2V0RW1haWwoY2xpZW50ZS5lbWFpbCk7XHJcbiAgICBzZXRFZGl0YW5kb0lkKGNsaWVudGUuaWQpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlcihpZCkge1xyXG4gICAgYXdhaXQgYXBpKGAvY2xpZW50ZXMvJHtpZH1gLCAnREVMRVRFJyk7XHJcbiAgICBjYXJyZWdhcigpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICA8aDI+Q2xpZW50ZXM8L2gyPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17c2FsdmFyfT5cclxuICAgICAgICA8aW5wdXQgYXJpYS1sYWJlbD1cIk5vbWVcIiBwbGFjZWhvbGRlcj1cIk5vbWVcIiB2YWx1ZT17bm9tZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXROb21lKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8aW5wdXQgYXJpYS1sYWJlbD1cIkVtYWlsXCIgcGxhY2Vob2xkZXI9XCJFbWFpbFwiIHZhbHVlPXtlbWFpbH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+e2VkaXRhbmRvSWQgPyAnU2FsdmFyJyA6ICdDYWRhc3RyYXInfTwvYnV0dG9uPlxyXG4gICAgICAgIHtlZGl0YW5kb0lkICYmIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2xpbXBhcn0+Q2FuY2VsYXI8L2J1dHRvbj59XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAge2Vycm8gJiYgPHAgY2xhc3NOYW1lPVwiZXJyb1wiPntlcnJvfTwvcD59XHJcblxyXG4gICAgICA8dGFibGU+XHJcbiAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgPHRyPjx0aD5Ob21lPC90aD48dGg+RW1haWw8L3RoPjx0aD48L3RoPjwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7Y2xpZW50ZXMubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgIDx0ciBrZXk9e2MuaWR9PlxyXG4gICAgICAgICAgICAgIDx0ZD57Yy5ub21lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPntjLmVtYWlsfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBlZGl0YXIoYyl9PkVkaXRhcjwvYnV0dG9uPnsnICd9XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlbW92ZXIoYy5pZCl9PlJlbW92ZXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC90Ym9keT5cclxuICAgICAgPC90YWJsZT5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==