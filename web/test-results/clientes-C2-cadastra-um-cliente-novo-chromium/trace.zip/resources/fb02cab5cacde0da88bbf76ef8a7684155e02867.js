import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Pedidos.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb9b7777";
import { api, moeda } from "/src/api.js";
var _jsxFileName = "C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Pedidos.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb9b7777";
var _s = $RefreshSig$();
export default function Pedidos() {
	_s();
	const [pedidos, setPedidos] = useState([]);
	const [clientes, setClientes] = useState([]);
	const [produtos, setProdutos] = useState([]);
	const [cliente, setCliente] = useState("");
	const [produtoId, setProdutoId] = useState("");
	const [quantidade, setQuantidade] = useState(1);
	const [itens, setItens] = useState([]);
	const [erro, setErro] = useState("");
	const carregar = () => api("/pedidos").then(setPedidos);
	useEffect(() => {
		carregar();
		api("/clientes").then(setClientes);
		api("/produtos").then(setProdutos);
	}, []);
	function adicionarItem() {
		const produto = produtos.find((p) => p.id === Number(produtoId));
		if (!produto) return;
		setItens([...itens, {
			nome: produto.nome,
			precoUnitario: produto.preco,
			quantidade: Number(quantidade)
		}]);
		setQuantidade(1);
	}
	async function criar(e) {
		e.preventDefault();
		try {
			await api("/pedidos", "POST", {
				cliente,
				itens
			});
			setCliente("");
			setItens([]);
			setErro("");
			carregar();
		} catch (err) {
			setErro(err.message);
		}
	}
	async function mudarStatus(id, status) {
		try {
			await api(`/pedidos/${id}/status`, "PATCH", { status });
			setErro("");
			carregar();
		} catch (err) {
			setErro(err.message);
		}
	}
	async function remover(id) {
		await api(`/pedidos/${id}`, "DELETE");
		carregar();
	}
	return /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "Pedidos" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: criar,
			children: [
				/* @__PURE__ */ _jsxDEV("select", {
					"aria-label": "Cliente",
					value: cliente,
					onChange: (e) => setCliente(e.target.value),
					children: [/* @__PURE__ */ _jsxDEV("option", {
						value: "",
						children: "Selecione o cliente"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this), clientes.map((c) => /* @__PURE__ */ _jsxDEV("option", {
						value: c.nome,
						children: c.nome
					}, c.id, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("select", {
					"aria-label": "Produto",
					value: produtoId,
					onChange: (e) => setProdutoId(e.target.value),
					children: [/* @__PURE__ */ _jsxDEV("option", {
						value: "",
						children: "Selecione o produto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this), produtos.map((p) => /* @__PURE__ */ _jsxDEV("option", {
						value: p.id,
						children: p.nome
					}, p.id, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					"aria-label": "Quantidade",
					type: "number",
					min: "1",
					value: quantidade,
					onChange: (e) => setQuantidade(e.target.value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: adicionarItem,
					children: "Adicionar item"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					children: "Criar pedido"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this),
		itens.length > 0 && /* @__PURE__ */ _jsxDEV("ul", { children: itens.map((item, i) => /* @__PURE__ */ _jsxDEV("li", { children: [
			item.quantidade,
			"x ",
			item.nome
		] }, i, true, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 9
		}, this),
		erro && /* @__PURE__ */ _jsxDEV("p", {
			className: "erro",
			children: erro
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 16
		}, this),
		/* @__PURE__ */ _jsxDEV("table", { children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("th", { children: "#" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Cliente" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 25
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Itens" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 41
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Total" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 55
			}, this),
			/* @__PURE__ */ _jsxDEV("th", { children: "Status" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 69
			}, this),
			/* @__PURE__ */ _jsxDEV("th", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 84
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: pedidos.map((p) => /* @__PURE__ */ _jsxDEV("tr", { children: [
			/* @__PURE__ */ _jsxDEV("td", { children: p.id }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: p.cliente }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: p.itens.map((i) => `${i.quantidade}x ${i.nome}`).join(", ") }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: moeda(p.total) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("select", {
				"aria-label": `Status do pedido ${p.id}`,
				value: p.status,
				onChange: (e) => mudarStatus(p.id, e.target.value),
				children: [
					/* @__PURE__ */ _jsxDEV("option", {
						value: "pendente",
						children: "pendente"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "pago",
						children: "pago"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 19
					}, this),
					/* @__PURE__ */ _jsxDEV("option", {
						value: "cancelado",
						children: "cancelado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 19
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 17
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => remover(p.id),
				children: "Remover"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 19
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 15
			}, this)
		] }, p.id, true, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
}
_s(Pedidos, "qioBXeP3+zB2t5HOGilNLrizDxg=");
_c = Pedidos;
var _c;
$RefreshReg$(_c, "Pedidos");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Pedidos.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Pedidos.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Pedidos.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/pages/Pedidos.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLEtBQUssYUFBYTs7OztBQUUzQixlQUFlLFNBQVMsVUFBVTs7Q0FDaEMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLENBQUMsQ0FBQztDQUN6QyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQyxDQUFDO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FFM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxDQUFDO0NBQzlDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDLENBQUM7Q0FDckMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FFbkMsTUFBTSxpQkFBaUIsSUFBSSxVQUFVLENBQUMsQ0FBQyxLQUFLLFVBQVU7Q0FFdEQsZ0JBQWdCO0VBQ2QsU0FBUztFQUNULElBQUksV0FBVyxDQUFDLENBQUMsS0FBSyxXQUFXO0VBQ2pDLElBQUksV0FBVyxDQUFDLENBQUMsS0FBSyxXQUFXO0NBQ25DLEdBQUcsQ0FBQyxDQUFDO0NBRUwsU0FBUyxnQkFBZ0I7RUFDdkIsTUFBTSxVQUFVLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxPQUFPLFNBQVMsQ0FBQztFQUMvRCxJQUFJLENBQUMsU0FBUztFQUNkLFNBQVMsQ0FDUCxHQUFHLE9BQ0g7R0FBRSxNQUFNLFFBQVE7R0FBTSxlQUFlLFFBQVE7R0FBTyxZQUFZLE9BQU8sVUFBVTtFQUFFLENBQ3JGLENBQUM7RUFDRCxjQUFjLENBQUM7Q0FDakI7Q0FFQSxlQUFlLE1BQU0sR0FBRztFQUN0QixFQUFFLGVBQWU7RUFDakIsSUFBSTtHQUNGLE1BQU0sSUFBSSxZQUFZLFFBQVE7SUFBRTtJQUFTO0dBQU0sQ0FBQztHQUNoRCxXQUFXLEVBQUU7R0FDYixTQUFTLENBQUMsQ0FBQztHQUNYLFFBQVEsRUFBRTtHQUNWLFNBQVM7RUFDWCxTQUFTLEtBQUs7R0FDWixRQUFRLElBQUksT0FBTztFQUNyQjtDQUNGO0NBRUEsZUFBZSxZQUFZLElBQUksUUFBUTtFQUNyQyxJQUFJO0dBQ0YsTUFBTSxJQUFJLFlBQVksR0FBRyxVQUFVLFNBQVMsRUFBRSxPQUFPLENBQUM7R0FDdEQsUUFBUSxFQUFFO0dBQ1YsU0FBUztFQUNYLFNBQVMsS0FBSztHQUNaLFFBQVEsSUFBSSxPQUFPO0VBQ3JCO0NBQ0Y7Q0FFQSxlQUFlLFFBQVEsSUFBSTtFQUN6QixNQUFNLElBQUksWUFBWSxNQUFNLFFBQVE7RUFDcEMsU0FBUztDQUNYO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7O0VBQ2Ysd0JBQUMsUUFBRDtHQUFNLFVBQVU7YUFBaEI7SUFDRSx3QkFBQyxVQUFEO0tBQVEsY0FBVztLQUFVLE9BQU87S0FBUyxXQUFXLE1BQU0sV0FBVyxFQUFFLE9BQU8sS0FBSztlQUF2RixDQUNFLHdCQUFDLFVBQUQ7TUFBUSxPQUFNO2dCQUFHO0tBQTJCOzs7O2VBQzNDLFNBQVMsS0FBSyxNQUNiLHdCQUFDLFVBQUQ7TUFBbUIsT0FBTyxFQUFFO2dCQUFPLEVBQUU7S0FBYSxHQUFyQyxFQUFFOzs7O1lBQW1DLENBQ25ELENBQ0s7Ozs7OztJQUNSLHdCQUFDLFVBQUQ7S0FBUSxjQUFXO0tBQVUsT0FBTztLQUFXLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO2VBQTNGLENBQ0Usd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQUc7S0FBMkI7Ozs7ZUFDM0MsU0FBUyxLQUFLLE1BQ2Isd0JBQUMsVUFBRDtNQUFtQixPQUFPLEVBQUU7Z0JBQUssRUFBRTtLQUFhLEdBQW5DLEVBQUU7Ozs7WUFBaUMsQ0FDakQsQ0FDSzs7Ozs7O0lBQ1Isd0JBQUMsU0FBRDtLQUFPLGNBQVc7S0FBYSxNQUFLO0tBQVMsS0FBSTtLQUFJLE9BQU87S0FBWSxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztJQUFJOzs7OztJQUN6SCx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFNBQVM7ZUFBZTtJQUFzQjs7Ozs7SUFDcEUsd0JBQUMsVUFBRDtLQUFRLE1BQUs7ZUFBUztJQUFvQjs7Ozs7R0FDdEM7Ozs7OztFQUVMLE1BQU0sU0FBUyxLQUNkLHdCQUFDLE1BQUQsWUFDRyxNQUFNLEtBQUssTUFBTSxNQUNoQix3QkFBQyxNQUFEO0dBQWEsS0FBSztHQUFXO0dBQUcsS0FBSztFQUFTLEtBQXJDOzs7O1NBQXFDLENBQy9DLEVBQ0M7Ozs7O0VBRUwsUUFBUSx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFRO0VBQVE7Ozs7O0VBRXRDLHdCQUFDLFNBQUQsYUFDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtHQUFJLHdCQUFDLE1BQUQsWUFBSSxJQUFLOzs7OztHQUFDLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7OztHQUFDLHdCQUFDLE1BQUQsWUFBSSxRQUFTOzs7OztHQUFDLHdCQUFDLE1BQUQsWUFBSSxRQUFTOzs7OztHQUFDLHdCQUFDLE1BQUQsWUFBSSxTQUFVOzs7OztHQUFDLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7RUFBSzs7OztXQUNqRjs7OztZQUNQLHdCQUFDLFNBQUQsWUFDRyxRQUFRLEtBQUssTUFDWix3QkFBQyxNQUFEO0dBQ0Usd0JBQUMsTUFBRCxZQUFLLEVBQUUsR0FBTzs7Ozs7R0FDZCx3QkFBQyxNQUFELFlBQUssRUFBRSxRQUFZOzs7OztHQUNuQix3QkFBQyxNQUFELFlBQUssRUFBRSxNQUFNLEtBQUssTUFBTSxHQUFHLEVBQUUsV0FBVyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQU07Ozs7O0dBQ3JFLHdCQUFDLE1BQUQsWUFBSyxNQUFNLEVBQUUsS0FBSyxFQUFNOzs7OztHQUN4Qix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtJQUFRLGNBQVksb0JBQW9CLEVBQUU7SUFBTSxPQUFPLEVBQUU7SUFBUSxXQUFXLE1BQU0sWUFBWSxFQUFFLElBQUksRUFBRSxPQUFPLEtBQUs7Y0FBbEg7S0FDRSx3QkFBQyxVQUFEO01BQVEsT0FBTTtnQkFBVztLQUFnQjs7Ozs7S0FDekMsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQU87S0FBWTs7Ozs7S0FDakMsd0JBQUMsVUFBRDtNQUFRLE9BQU07Z0JBQVk7S0FBaUI7Ozs7O0lBQ3JDOzs7OztZQUNOOzs7OztHQUNKLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxVQUFEO0lBQVEsZUFBZSxRQUFRLEVBQUUsRUFBRTtjQUFHO0dBQWU7Ozs7WUFBSzs7Ozs7RUFDNUQsS0FiSyxFQUFFOzs7O1NBYVAsQ0FDTCxFQUNJOzs7O1VBQ0Y7Ozs7O0NBQ0E7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUGVkaWRvcy5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgYXBpLCBtb2VkYSB9IGZyb20gJy4uL2FwaS5qcyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQZWRpZG9zKCkge1xyXG4gIGNvbnN0IFtwZWRpZG9zLCBzZXRQZWRpZG9zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY2xpZW50ZXMsIHNldENsaWVudGVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcHJvZHV0b3MsIHNldFByb2R1dG9zXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW2NsaWVudGUsIHNldENsaWVudGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtwcm9kdXRvSWQsIHNldFByb2R1dG9JZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3F1YW50aWRhZGUsIHNldFF1YW50aWRhZGVdID0gdXNlU3RhdGUoMSk7XHJcbiAgY29uc3QgW2l0ZW5zLCBzZXRJdGVuc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Vycm8sIHNldEVycm9dID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBjYXJyZWdhciA9ICgpID0+IGFwaSgnL3BlZGlkb3MnKS50aGVuKHNldFBlZGlkb3MpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY2FycmVnYXIoKTtcclxuICAgIGFwaSgnL2NsaWVudGVzJykudGhlbihzZXRDbGllbnRlcyk7XHJcbiAgICBhcGkoJy9wcm9kdXRvcycpLnRoZW4oc2V0UHJvZHV0b3MpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgZnVuY3Rpb24gYWRpY2lvbmFySXRlbSgpIHtcclxuICAgIGNvbnN0IHByb2R1dG8gPSBwcm9kdXRvcy5maW5kKChwKSA9PiBwLmlkID09PSBOdW1iZXIocHJvZHV0b0lkKSk7XHJcbiAgICBpZiAoIXByb2R1dG8pIHJldHVybjtcclxuICAgIHNldEl0ZW5zKFtcclxuICAgICAgLi4uaXRlbnMsXHJcbiAgICAgIHsgbm9tZTogcHJvZHV0by5ub21lLCBwcmVjb1VuaXRhcmlvOiBwcm9kdXRvLnByZWNvLCBxdWFudGlkYWRlOiBOdW1iZXIocXVhbnRpZGFkZSkgfSxcclxuICAgIF0pO1xyXG4gICAgc2V0UXVhbnRpZGFkZSgxKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGNyaWFyKGUpIHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaSgnL3BlZGlkb3MnLCAnUE9TVCcsIHsgY2xpZW50ZSwgaXRlbnMgfSk7XHJcbiAgICAgIHNldENsaWVudGUoJycpO1xyXG4gICAgICBzZXRJdGVucyhbXSk7XHJcbiAgICAgIHNldEVycm8oJycpO1xyXG4gICAgICBjYXJyZWdhcigpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm8oZXJyLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gbXVkYXJTdGF0dXMoaWQsIHN0YXR1cykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpKGAvcGVkaWRvcy8ke2lkfS9zdGF0dXNgLCAnUEFUQ0gnLCB7IHN0YXR1cyB9KTtcclxuICAgICAgc2V0RXJybygnJyk7XHJcbiAgICAgIGNhcnJlZ2FyKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJybyhlcnIubWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiByZW1vdmVyKGlkKSB7XHJcbiAgICBhd2FpdCBhcGkoYC9wZWRpZG9zLyR7aWR9YCwgJ0RFTEVURScpO1xyXG4gICAgY2FycmVnYXIoKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbj5cclxuICAgICAgPGgyPlBlZGlkb3M8L2gyPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17Y3JpYXJ9PlxyXG4gICAgICAgIDxzZWxlY3QgYXJpYS1sYWJlbD1cIkNsaWVudGVcIiB2YWx1ZT17Y2xpZW50ZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDbGllbnRlKGUudGFyZ2V0LnZhbHVlKX0+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWNpb25lIG8gY2xpZW50ZTwvb3B0aW9uPlxyXG4gICAgICAgICAge2NsaWVudGVzLm1hcCgoYykgPT4gKFxyXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17Yy5pZH0gdmFsdWU9e2Mubm9tZX0+e2Mubm9tZX08L29wdGlvbj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDxzZWxlY3QgYXJpYS1sYWJlbD1cIlByb2R1dG9cIiB2YWx1ZT17cHJvZHV0b0lkfSBvbkNoYW5nZT17KGUpID0+IHNldFByb2R1dG9JZChlLnRhcmdldC52YWx1ZSl9PlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjaW9uZSBvIHByb2R1dG88L29wdGlvbj5cclxuICAgICAgICAgIHtwcm9kdXRvcy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3AuaWR9IHZhbHVlPXtwLmlkfT57cC5ub21lfTwvb3B0aW9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgPGlucHV0IGFyaWEtbGFiZWw9XCJRdWFudGlkYWRlXCIgdHlwZT1cIm51bWJlclwiIG1pbj1cIjFcIiB2YWx1ZT17cXVhbnRpZGFkZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWFudGlkYWRlKGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXthZGljaW9uYXJJdGVtfT5BZGljaW9uYXIgaXRlbTwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkNyaWFyIHBlZGlkbzwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICB7aXRlbnMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPHVsPlxyXG4gICAgICAgICAge2l0ZW5zLm1hcCgoaXRlbSwgaSkgPT4gKFxyXG4gICAgICAgICAgICA8bGkga2V5PXtpfT57aXRlbS5xdWFudGlkYWRlfXgge2l0ZW0ubm9tZX08L2xpPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC91bD5cclxuICAgICAgKX1cclxuICAgICAge2Vycm8gJiYgPHAgY2xhc3NOYW1lPVwiZXJyb1wiPntlcnJvfTwvcD59XHJcblxyXG4gICAgICA8dGFibGU+XHJcbiAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgPHRyPjx0aD4jPC90aD48dGg+Q2xpZW50ZTwvdGg+PHRoPkl0ZW5zPC90aD48dGg+VG90YWw8L3RoPjx0aD5TdGF0dXM8L3RoPjx0aD48L3RoPjwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7cGVkaWRvcy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgPHRyIGtleT17cC5pZH0+XHJcbiAgICAgICAgICAgICAgPHRkPntwLmlkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPntwLmNsaWVudGV9PC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+e3AuaXRlbnMubWFwKChpKSA9PiBgJHtpLnF1YW50aWRhZGV9eCAke2kubm9tZX1gKS5qb2luKCcsICcpfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPnttb2VkYShwLnRvdGFsKX08L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3QgYXJpYS1sYWJlbD17YFN0YXR1cyBkbyBwZWRpZG8gJHtwLmlkfWB9IHZhbHVlPXtwLnN0YXR1c30gb25DaGFuZ2U9eyhlKSA9PiBtdWRhclN0YXR1cyhwLmlkLCBlLnRhcmdldC52YWx1ZSl9PlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGVuZGVudGVcIj5wZW5kZW50ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGFnb1wiPnBhZ288L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhbmNlbGFkb1wiPmNhbmNlbGFkbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICA8dGQ+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZW1vdmVyKHAuaWQpfT5SZW1vdmVyPC9idXR0b24+PC90ZD5cclxuICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvdGJvZHk+XHJcbiAgICAgIDwvdGFibGU+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=