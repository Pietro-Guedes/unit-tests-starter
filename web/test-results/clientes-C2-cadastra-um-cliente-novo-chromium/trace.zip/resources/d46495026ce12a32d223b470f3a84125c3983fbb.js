import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/54706916836/Documents/SENAI/TS/unit-tests-starter/web/src/index.css"
const __vite__css = "body {\r\n  font-family: sans-serif;\r\n  max-width: 720px;\r\n  margin: 0 auto;\r\n  padding: 16px;\r\n}\r\n\r\nnav,\r\nform {\r\n  display: flex;\r\n  gap: 8px;\r\n  flex-wrap: wrap;\r\n  margin-bottom: 16px;\r\n}\r\n\r\ntable {\r\n  width: 100%;\r\n  border-collapse: collapse;\r\n}\r\n\r\nth,\r\ntd {\r\n  border-bottom: 1px solid #ddd;\r\n  padding: 6px;\r\n  text-align: left;\r\n}\r\n\r\n.erro {\r\n  color: #b00020;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))